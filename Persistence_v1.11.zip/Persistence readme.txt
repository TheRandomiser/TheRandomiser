Persistence - by Randomiser#0769

Persistence is a modded levelpack based around the custom property "Persist", which lets you bring objects and rules between levels.

100% requirements are 50/2/5