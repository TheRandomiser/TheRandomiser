CONTROLS:
arrows/WASD: Move
Space/Enter: Select level
Z: Undo
R: Restart level
ESC: Exit to level select

MUSIC:
Chepaki - Sand Is Hot
https://www.newgrounds.com/audio/listen/974436