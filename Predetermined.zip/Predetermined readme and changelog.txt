PREDETERMINED
by Randomiser

Made for a competition with the theme "Cog In The Machine" on the Baba Is You discord. This pack makes heavy use of custom lua for gameplay and to tell a story.

It was a peaceful day in the City Of Golem... That is, until the evil wizard Me stole the Gem Of Control! He began using it to control the minds of everyone in the kingdom. It's up to you! Use your power of free will to stop Me and save your friends from becoming automatons!

It should be easy. All you have to do is follow the arrows.

=========
CHANGELOG:
v1.1	3 Jan, 2023:
- Cheese fix to "Bog in the Machine"
- Added optional flavour text that may also act as hints to levels A, B, and C
- Slightly(?) nerfed "Jiji Jinxed"

v1.0	2 Jan, 2023:
- First public release

v0.99	28 Dec, 2022:
- Initial submission for competition