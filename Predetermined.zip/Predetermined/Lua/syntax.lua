function command(key,player_)
	local keyid = -1
	if (keys[key] ~= nil) then
		keyid = keys[key]
	else
		print("no such key")
		return
	end
	
	if hasarrows then
		local cd = currentdir
		if keyid <= 4 then
			if cd == "any" and keyid ~= 4 then
				cd = keyid
			elseif not cd then
				keyid = 4
				cd = 4
			elseif keyid~=cd then
				if currentdirname=="arrow2" and (keyid==nextdir or nextdir=="any") and keyid~=4 then
					local unit = currentdirunit
					local mats2 = {{"empty",unit.values[ID],unit.values[ID]}}
					doconvert({currentdirunit.fixed,"convert",mats2})
					if nextdirname=="arrow" then
						thingtobe="arrow2"
					elseif nextdirname=="arrow1" or nextdirname=="what1" then
						thingtobe="empty"
					elseif nextdirname=="what" then
						thingtobe="arrow2"
						nextdirunit.values[DIR]=keyid
					end
					local unit = nextdirunit
					local mats2 = {{thingtobe,unit.values[ID],unit.values[ID]}}
					doconvert({nextdirunit.fixed,"convert",mats2})
				elseif #(findall({"dust",{}})) > 0 and keyid==4 then
					currentdirname="arrow1"
					for i,unitid in pairs(findall({"dust",{}})) do
						local unit = mmf.newObject(unitid)
						local mats2 = {{"empty",unit.values[ID],unit.values[ID]}}
						doconvert({unit.fixed,"convert",mats2})
					end
					
				else
					return
				end
			end
		end
		
		if keyid <= 4 then
			if currentdirunit then
				if currentdirname~="arrow2" then
					if currentdirname=="arrow" then
						thingtobe="arrow2"
					elseif currentdirname=="arrow1" or currentdirname=="what1" then
						thingtobe="empty"
					elseif currentdirname=="what" then
						thingtobe="arrow2"
						currentdirunit.values[DIR]=keyid
					end
					local unit = currentdirunit
					local mats2 = {{thingtobe,unit.values[ID],unit.values[ID]}}
					doconvert({currentdirunit.fixed,"convert",mats2})
				end
			end
		end
	end
	
	local player = 1
	if (player_ ~= nil) then
		player = player_
	end
	
	do_mod_hook("command_given", {key,player})
	
	if (keyid <= 4) then
		if (generaldata5.values[AUTO_ON] == 0) then
			local drs = ndirs[keyid+1]
			local ox = drs[1]
			local oy = drs[2]
			local dir = keyid
			
			last_key = keyid
			
			if (auto_dir[player] == nil) then
				auto_dir[player] = 4
			end
			
			auto_dir[player] = 4
			
			if (spritedata.values[VISION] == 1) and (dir == 3) then
				if (#units > 0) then
					changevisiontarget()
				end
				movecommand(ox,oy,dir,player,nil,true)
				MF_update()
			else
				movecommand(ox,oy,dir,player)
				MF_update()
			end
		else
			if (auto_dir[player] == nil) then
				auto_dir[player] = 4
			end
			
			auto_dir[player] = keyid
			
			if (auto_dir[1] == nil) and (featureindex["you2"] == nil) then
				auto_dir[1] = keyid
			end
		end
	end
	
	if (keyid == 5) then
		MF_restart(false)
		--do_mod_hook("level_restart", {})
	elseif (keyid == 8) then
		MF_restart(true)
		--do_mod_hook("level_restart", {})
	end
	
	dolog(key)
end

function command_auto()
	local moving = false
	local firstp = -1
	local secondp = -1
	
	if (auto_dir[1] ~= nil) then
		firstp = auto_dir[1]
		moving = true
	else
		firstp = 4
		moving = true
	end
	
	if (auto_dir[2] ~= nil) then
		secondp = auto_dir[2]
		moving = true
	else
		secondp = 4
		moving = true
	end
	
	do_mod_hook("turn_auto", {firstp,secondp,moving})
	
	if moving and (generaldata5.values[AUTO_ON] > 0) then
		for i=1,generaldata5.values[AUTO_ON] do
			if (firstp ~= 4) then
				last_key = firstp
			elseif (secondp ~= 4) then
				last_key = secondp
			else
				last_key = 4
			end
			
			local drs = ndirs[firstp+1]
			local ox = drs[1]
			local oy = drs[2]
			local dir = firstp
			
			if (spritedata.values[VISION] == 1) and (dir == 3) then
				if (#units > 0) then
					changevisiontarget()
				end
				movecommand(ox,oy,dir,3,secondp,true)
			else
				movecommand(ox,oy,dir,3,secondp)
			end
		end
		
		MF_update()
	end
	
	auto_dir = {}
end

--stop TURN from happening twice if object is transformed mid-turn (is this even intended behavior?)
function addunit(id,undoing_,levelstart_)
	local unitid = #units + 1
	
	units[unitid] = {}
	units[unitid] = mmf.newObject(id)
	
	local unit = units[unitid]
	local undoing = undoing_ or false
	local levelstart = levelstart_ or false
	
	getmetadata(unit)
	
	local truename = unit.className
	
	if (changes[truename] ~= nil) then
		dochanges(id)
	end
	
	if (unit.values[ID] == -1) then
		unit.values[ID] = newid()
	end

	if (unit.values[XPOS] > 0) and (unit.values[YPOS] > 0) then
		addunitmap(id,unit.values[XPOS],unit.values[YPOS],unit.strings[UNITNAME])
	end
	
	if (unit.values[TILING] == 1) then
		table.insert(tiledunits, unit.fixed)
	end
	
	if (unit.values[TILING] > 1) then
		table.insert(animunits, unit.fixed)
	end
	
	local name = getname(unit)
	local name_ = unit.strings[NAME]
	local name__ = unit.strings[UNITNAME]
	unit.originalname = unit.strings[UNITNAME]
	
	if (unitlists[name] == nil) then
		unitlists[name] = {}
	end
	
	if (string.sub(name_, 1, 5) == "text_") then
		unit.flags[META] = true
	end
	
	table.insert(unitlists[name], unit.fixed)
	
	if (name ~= name__) then
		if (unitlists[name__] == nil) then
			unitlists[name__] = {}
		end
		table.insert(unitlists[name__], unit.fixed)
	end
	
	if (unit.strings[UNITTYPE] ~= "text") or ((unit.strings[UNITTYPE] == "text") and (unit.values[TYPE] == 0)) then
		objectlist[name_] = 1
	end
	
	if (unit.strings[UNITTYPE] == "text") then
		table.insert(codeunits, unit.fixed)
		updatecode = 1
		
		if (unit.values[TYPE] == 0) then
			local matname = string.sub(unit.strings[UNITNAME], 6)
			if (unitlists[matname] == nil) then
				unitlists[matname] = {}
			end
		elseif (unit.values[TYPE] == 5) then
			table.insert(letterunits, unit.fixed)
		end
	end
	
	unit.colour = {}
	
	if (unit.strings[UNITNAME] ~= "level") and (unit.className ~= "specialobject") then
		local cc1,cc2 = setcolour(unit.fixed)
		unit.colour = {cc1,cc2}
	end
	
	unit.back_init = 0
	unit.broken = 0
	
	if (unit.className ~= "path") and (unit.className ~= "specialobject") then
		statusblock({id},undoing,true)
		MF_animframe(id,math.random(0,2))
	end
	
	unit.active = false
	unit.new = true
	unit.colours = {}
	unit.currcolour = 0
	unit.followed = -1
	unit.holder = 0
	unit.xpos = unit.values[XPOS]
	unit.ypos = unit.values[YPOS]
	
	if (spritedata.values[VISION] == 1) and (undoing == false) then
		local hasvision = hasfeature(name,"is","3d",id,unit.values[XPOS],unit.values[YPOS])
		if (hasvision ~= nil) then
			table.insert(visiontargets, id)
		elseif (spritedata.values[CAMTARGET] == unit.values[ID]) then
			visionmode(0,0,nil,{unit.values[XPOS],unit.values[YPOS],unit.values[DIR]})
		end
	end
	
	if (spritedata.values[VISION] == 1) and (spritedata.values[CAMTARGET] ~= unit.values[ID]) then
		if (unit.values[ZLAYER] <= 15) then
			if (unit.values[ZLAYER] > 10) then
				setupvision_wall(unit.fixed)
			end
			
			MF_setupvision_single(unit.fixed)
		end
	end
	
	if generaldata.flags[LOGGING] and (generaldata.flags[RESTARTED] == false) then
		if levelstart then
			dolog("init_object","event",unit.strings[UNITNAME] .. ":" .. tostring(unit.values[XPOS]) .. ":" .. tostring(unit.values[YPOS]))
		elseif (undoing == false) then
			dolog("new_object","event",unit.strings[UNITNAME] .. ":" .. tostring(unit.values[XPOS]) .. ":" .. tostring(unit.values[YPOS]))
		end
	end
end