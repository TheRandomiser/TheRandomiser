function getlevelnumber()
	local result = ""
	local nothing = false
	
	local id = leveltree_id[#leveltree_id]
	local id2 = leveltree_id[#leveltree_id - 1] or ""
	
	if (id2 == "<empty>") then
		id2 = ""
	end
	
	if (#leveltree_id == 1) then
		if (id == "???") or (id == "baba") then
			result = result .. id
		end
	elseif (#leveltree_id == 2) then
		if (id2 == "???") or (id2 == "baba") then
			result = result .. id2 .. "-"
		end
		
		result = result .. id
	elseif (string.len(id2) > 0) then
		result = result .. id2 .. "-" .. id
	else
		result = result .. id
	end
	
	if (id == "<empty>") then
		nothing = true
	end
	
	if nothing then
		result = " "
	end

	return result
end