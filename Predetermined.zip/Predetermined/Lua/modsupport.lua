gotglitch = MF_read("save",generaldata.strings[WORLD],"gotglitch")
if gotglitch~="1" then
	gotglitch=false
end
kekestate = MF_read("save",generaldata.strings[WORLD],"keke")
fofostate = MF_read("save",generaldata.strings[WORLD],"fofo")
jijistate = MF_read("save",generaldata.strings[WORLD],"jiji")

MF_loadsound("glitch")

currentdir = nil
currentdirunit = nil
currentdirname = nil

function getcurrentdir()
	nextdir = nil
	nextdirunit = nil
	nextfirname = nil
	local foundarrow = false
	for var=roomsizex+1,roomsizex*3 do
		if not foundarrow then
			cdtile = var
			if (unitmap[cdtile] ~= nil) then
				for c,d in ipairs(unitmap[cdtile]) do
					if (d ~= unitid) then
						local unit = mmf.newObject(d)
						local name = getname(unit)
						if string.sub(name,1,4)=="what" then
							foundarrow = true
							local dir = "any"
							currentdir=dir
							currentdirunit=unit
							currentdirname=name
						elseif string.sub(name,1,5)=="arrow" then
							foundarrow = true
							local dir = unit.values[DIR]
							currentdir=dir
							currentdirunit=unit
							currentdirname=name
						end
					end
				end
			end
		else
			break
		end
	end
	if not foundarrow then
		currentdir=nil
		currentdirunit=nil
		return
	end
	if foundarrow and currentdirname=='arrow2' then
		foundarrow = false
		for var=cdtile+1,cdtile+3 do
			if not foundarrow then
				cdtile = var
				if (unitmap[cdtile] ~= nil) then
					for c,d in ipairs(unitmap[cdtile]) do
						if (d ~= unitid) then
							local unit = mmf.newObject(d)
							local name = getname(unit)
							if string.sub(name,1,4)=="what" then
								foundarrow = true
								local dir = "any"
								nextdir=dir
								nextdirunit=unit
								nextdirname=name
							elseif string.sub(name,1,5)=="arrow" then
								foundarrow = true
								local dir = unit.values[DIR]
								nextdir=dir
								nextdirunit=unit
								nextdirname=name
							end
						end
					end
				end
			else
				break
			end
		end
	end
end

mod_hook_functions =
{
	level_start =
	{
		-- Functions added to this table will be called on level start.
		levelstartfunction = function()
			generaldata.values[ONLYARROWS] = 0
			getcurrentdir()
			if currentdir then
				hasarrows=true
			else
				hasarrows=false
			end
			objectlist["dust"] = 1
			objectlist["empty"] = 1
		
			currlevel = generaldata.strings[CURRLEVEL]
			if currlevel=="15level" then
				if not gotglitch and not (jijistate=="dead") then
					MF_loadbackimage("bluebg")
				end
				if kekestate=="dead" then
					if gotglitch then
						create("dust",11,12,2,nil,nil,nil,true,nil)
					else
						create("skull",11,12,3,nil,nil,nil,true,nil)
					end
				else
					create("keke",11,12,2,nil,nil,nil,true,nil)
					create("glitchr",5,2,2,nil,nil,nil,true,nil)
				end
				if fofostate=="dead" then
					if gotglitch then
						create("dust",12,9,0,nil,nil,nil,true,nil)
					else
						create("skull",12,9,3,nil,nil,nil,true,nil)
					end
				else
					create("fofo",12,9,0,nil,nil,nil,true,nil)
					create("glitchg",5.1,2.9,2,nil,nil,nil,true,nil)
				end
				if jijistate=="dead" then
					if gotglitch then
						create("dust",16,9,2,nil,nil,nil,true,nil)
					else
						create("skull",16,9,3,nil,nil,nil,true,nil)
					end
				else
					create("jiji",16,9,2,nil,nil,nil,true,nil)
					create("glitchb",5.2,3.8,2,nil,nil,nil,true,nil)
				end
				animate()
			elseif currlevel=="14level" then
				savedchars={}
				if kekestate=="saved" then
					table.insert(savedchars,"keke")
				end
				if fofostate=="saved" then
					table.insert(savedchars,"fofo")
				end
				if jijistate=="saved" then
					table.insert(savedchars,"jiji")
				end
				if #savedchars<3 or not gotglitch then
					create("whatglitch",2,5,1,nil,nil,nil,true,nil)
				end
			elseif gotglitch then
				if currlevel=="klevel" then
					--create(name,x,y,dir,oldx_,oldy_,float_,skipundo_,leveldata_)
					create("arrow",8,2,1,nil,nil,nil,true,nil)
				elseif currlevel=="flevel" then
					create("arrow",14,1,0,nil,nil,nil,true,nil)
				elseif currlevel=="jlevel" then
					create("arrow",6,2,2,nil,nil,nil,true,nil)
				end
			end
		end
	},
	level_end =
	{
		-- Functions added to this table will be called on level end.
	},
	level_win =
	{
		-- Functions added to this table will be called on level win, before running any of the winning-related code.
		winfunction = function()
			local world = generaldata.strings[WORLD]
			if currlevel=="klevel" then
				if next (findall({"keke",{}})) then
					MF_store("save",world,"keke","saved")
					kekestate = "saved"
				else
					MF_store("save",world,"keke","dead")
					kekestate = "dead"
				end
			elseif currlevel=="flevel" then
				if next (findall({"fofo",{}})) then
					MF_store("save",world,"fofo","saved")
					fofostate = "saved"
				else
					MF_store("save",world,"fofo","dead")
					fofostate = "dead"
				end
			elseif currlevel=="jlevel" then
				if next (findall({"jiji",{}})) then
					MF_store("save",world,"jiji","saved")
					jijistate = "saved"
				else
					MF_store("save",world,"jiji","dead")
					jijistate = "dead"
				end
			elseif currlevel=="16level" then
				generaldata.values[ONLYARROWS] = 0
			end
		end
	},
	level_win_after =
	{
		-- Functions added to this table will be called on level win, after running the winning-related code.
	},
	level_restart =
	{
		-- Functions added to this table will be called when the player restarts a level.
	},
	rule_update =
	{
		-- Functions added to this table will be called when rules are updated. Extra data: {is_this_a_repeated_update [false = no, true = yes]} <-- the extra variable is true e.g. when Word-related rules require the rules to be refreshed multiple times in a row.
	},
	rule_baserules =
	{
		-- Functions added to this table will be called as the game adds the base rules into the rule list (i.e. ones that aren't visible in the rule list). You can use addbaserule(word 1, word 2, word 3) here to add your own base rules.
		baserulefunction = function()
			currlevel = generaldata.strings[CURRLEVEL]
			addbaserule("pixel","is","stop")
			if currlevel=="7level" or currlevel=="10level" or currlevel=="flevel" then
				addbaserule("baba","eat","orb")
				addbaserule("orb","has","dust")
				addbaserule("orb","is","bonus")
				addbaserule("dust","is","hide")
				addbaserule("crab","is","hide",{{"not without",{"dust"}}})
				addbaserule("bubble","is","hide",{{"without",{"dust"}}})
			end
			
			addbaserule("arrow1","mimic","arrow")
			addbaserule("arrow2","mimic","arrow")
			
			if currlevel=="15level" then
				addbaserule("sign","is","you",{{"nextto",{"cursor"}}})
				addbaserule("sign","is","still")
				addbaserule("glitchr","is","hide",{{"not poweredz",{}}})
				addbaserule("glitchg","is","hide",{{"not poweredz",{}}})
				addbaserule("glitchb","is","hide",{{"not poweredz",{}}})				
				if kekestate=="saved" and fofostate=="saved" and jijistate=="saved" then
					addbaserule("paper","is","boom",{{"nextto",{"cursor"}}})
					MF_loadbackimage("bluebg")
				else
					addbaserule("cursor","is","powerz",{{"nextto",{"paper"}}})
					addbaserule("cursor","is","powerz",{{"nextto",{"tower"}}})
					addbaserule("pixel","is","hide",{{"poweredz",{}}})
					addbaserule("cloud","is","hide",{{"poweredz",{}}})
					addbaserule("cloud2","is","hide",{{"poweredz",{}}})
					addbaserule("rope","is","hide",{{"poweredz",{}}})
				end
			elseif currlevel=="16level" then
				objectlist["algae"] = 1
				objectlist["bubble"] = 1
				objectlist["crab"] = 1
				objectlist["eye"] = 1
				addbaserule("sprout","is","hide")
				addbaserule("seed","is","hide")
				addbaserule("algae","is","hide")
				addbaserule("bubble","is","hide")
				addbaserule("crab","is","hide")
				addbaserule("dust","is","hide")
				addbaserule("eye","is","hide")
				addbaserule("pillar","is","still")
				addbaserule("pillar","is","you",{{"near",{"baba"}}})
				addbaserule("baba","make","algae",{{"not feeling",{"you"}}})
				addbaserule("algae","is","bubble")
				addbaserule("baba","is","right",{{"on",{"bubble","bubble","bubble","bubble","bubble","bubble"}}})
				addbaserule("baba","make","crab",{{"on",{"bubble","bubble","bubble","bubble","bubble","bubble"}}})
				addbaserule("crab","is","dust")
				addbaserule("baba","is","down",{{"on",{"dust","dust","dust"}}})
				addbaserule("baba","is","not right",{{"on",{"dust","dust","dust"}}})
				addbaserule("baba","is","powerz",{{"not feeling",{"you"}}})
				addbaserule("level","is","auto",{{"poweredz",{}}})
				addbaserule("baba","make","eye",{{"on",{"dust","dust","dust","dust","dust","dust"}}})
				addbaserule("baba","is","not auto",{{"nextto",{"eye"}},{"not on",{"bubble","bubble","bubble","bubble"}}})
				addbaserule("baba","is","auto",{{"not without",{"eye"}}})
				addbaserule("baba","follow","sprout",{{"not without",{"eye"}}})
				addbaserule("sprout","is","empty",{{"on",{"baba"}},{"poweredz",{}}})
				addbaserule("baba","follow","seed",{{"not without",{"eye"}},{"without",{"sprout"}}})
				addbaserule("baba","is","phantom",{{"without",{"seed"}}})

				addbaserule("seed","is","empty",{{"on",{"baba"}},{"poweredz",{}}})
				addbaserule("baba","is","empty",{{"near",{"flower"}},{"not on",{"grass"}}})
				addbaserule("level","is","you",{{"without",{"baba"}}})
				addbaserule("level","is","win",{{"without",{"baba"}}})
			elseif currlevel=="klevel" or currlevel=="flevel" or currlevel=="jlevel" then
				addbaserule("arrow","is","pink",{{"on",{"foot"}}})
				addbaserule("arrow2","is","pink",{{"on",{"foot"}}})
				addbaserule("foot","is","hide")
				if gotglitch then
					addbaserule("paper","is","hide")
					addbaserule("paper","is","empty")
				end
			elseif currlevel=="14level" then
				addbaserule("whatglitch","is","glitch")
				addbaserule("line","is","hide")
				addbaserule("foot","is","hide")
				addbaserule("me","follow","baba")
				if gotglitch then
					savedchars={}
					if kekestate=="saved" then
						table.insert(savedchars,"keke")
					end
					if fofostate=="saved" then
						table.insert(savedchars,"fofo")
					end
					if jijistate=="saved" then
						table.insert(savedchars,"jiji")
					end

					if next(savedchars) then
						addbaserule("arrow","is","pink",{{"not lonely",{}}})
						addbaserule("arrow2","is","pink",{{"not lonely",{}}})
						
						addbaserule("arrow","is","nudgeright",{{"on",{savedchars[1]}}})
						addbaserule(savedchars[1],"is","nudgeright",{{"not on",{"foot"}}})
						addbaserule("arrow","is","nudgeup",{{"on",{"foot"}},{"not on",{savedchars[2]}}})
					end
					if #savedchars>=2 then
						addbaserule("arrow","is","nudgeright",{{"on",{savedchars[2]}},{"not on",{savedchars[1]}}})
						addbaserule(savedchars[2],"is","nudgeright",{{"not on",{"foot"}}})
						addbaserule(savedchars[2],"is","nudgeright",{{"on",{savedchars[1]}}})
						addbaserule("arrow","is","nudgeup",{{"on",{"foot"}},{"not on",{savedchars[1]}},{"on",{savedchars[2]}}})
					end
					if #savedchars>=3 then
						addbaserule("arrow","is","nudgeleft",{{"on",{savedchars[3]}}})
						addbaserule(savedchars[3],"is","nudgeleft",{{"not on",{"foot"}}})
					end
				end
			end
			
		end
	},
	rule_update_after =
	{
		-- Functions added to this table will be called after rules have been updated. Extra data: {is_this_a_repeated_update [false = no, true = yes]} <-- the extra variable is true e.g. when Word-related rules require the rules to be refreshed multiple times in a row.
	},
	command_given =
	{
		-- Functions added to this table will be called when a player command starts resolving. Extra data: {command, player_id}
		commandfunction = function()
			getcurrentdir()
			if currlevel=="14level" and gotglitch then
				
				local chararrows = {["keke"]=1, ["fofo"]=0, ["jiji"]=2}
				
				if #undobuffer == 4 and next(savedchars) then
					create(savedchars[1],0,2,0,nil,nil,nil,false,nil)
					create("arrow",0,2,chararrows[savedchars[1]],nil,nil,nil,false,nil)
				elseif #undobuffer == 10 and #savedchars>=2 then
					create(savedchars[2],0,2,0,nil,nil,nil,false,nil)
					create("arrow",0,2,chararrows[savedchars[2]],nil,nil,nil,false,nil)
				elseif #undobuffer == 18 and #savedchars>=3 then
					create(savedchars[3],23,2,2,24,2,nil,false,nil)
					create("arrow",23,2,chararrows[savedchars[3]],nil,nil,nil,false,nil)
				end
			end
		end
	},
	turn_auto =
	{
		-- Functions added to this table will be called when a turn starts resolving due to 'Level Is Auto'. Extra data: {player_1_direction, player_2_direction, is_a_player_moving [false = no, true = yes]}
	},
	turn_end =
	{
		turnendfunction = function()
			if currlevel == "16level" then
				if babamoved == false then
					generaldata2.strings[TURNSOUND] = "silent"
				end
				babamoved = false
			end
			getcurrentdir()
			if hasarrows then
				if currentdir == nil then
					auto_on = 1
					generaldata5.values[AUTO_ON] = 1
				else
					auto_on = 0
					generaldata5.values[AUTO_ON] = 0
				end
			elseif hasfeature("level","is","auto",1) then
				generaldata5.values[AUTO_ON] = 1
				if currlevel=="16level" then
					generaldata.values[ONLYARROWS] = 1
				end
			else
				generaldata5.values[AUTO_ON] = 0
			end
		end
	},
	always =
	{
		-- Functions added to this table will be called every frame. This can get quite slow, so be aware of that! Extra data: {time_from_game_start}
	},
	effect_once =
	{
		-- Functions added to this table will be called once at the end of every turn.
	},
	effect_always =
	{
		-- Functions added to this table will be called every frame when you're playing a level.
	},
	undoed =
	{
		-- Functions added to this table will be called when the player does an undo input.
	},
	undoed_after =
	{
		-- Functions added to this table will be called after undo has taken effect.
		undofunction = function()
			getcurrentdir()
			if hasarrows then
				if currentdir == nil then
					auto_on = 1
					generaldata5.values[AUTO_ON] = 1
				else
					auto_on = 0
					generaldata5.values[AUTO_ON] = 0
				end
			end
		end
	},
	levelpack_end =
	{
		-- Functions added to this table will be called when the player does the Level Is End ending in a levelpack. Note that if any functions are run here, the normal victory effects won't be displayed.
	},
	levelpack_done =
	{
		-- Functions added to this table will be called when the player does the All Is Done ending in a levelpack. Note that if any functions are run here, the normal victory effects won't be displayed.
	},
	text_input_ok =
	{
		-- Functions added to this table will be called when the user has input text in the text input dialogue and pressed OK. Extra data: {sanitized_text}
	},
}

buttonclick_list = {}

function do_mod_hook(name,extra_)
	local extra = extra_ or {}
	local mods_run = false
	
	if (mod_hook_functions[name] ~= nil) then
		for i,v in pairs(mod_hook_functions[name]) do
			if (type(v) == "function") then
				v(extra)
				mods_run = true
			end
		end
	end
	
	return mods_run
end

function buttonclicked(name)
	if (string.len(name) > 0) and (buttonclick_list[name] ~= nil) then
		buttonclick_list[name]()
	end
end

function setupmods_global()
	local files = MF_filelist("Data/Lua/","*.lua")
	
	table.sort(files)
	
	for i,file in ipairs(files) do
		print("Added custom lua file " .. file)
		dofile("Data/Lua/" .. file)
	end
end

function setupmods_levelpack()
	local world = generaldata.strings[WORLD]
	local files = MF_filelist("Data/Worlds/" .. world .. "/Lua/","*.lua")
	
	--MF_alert(world .. ": " .. tostring(#files))
	
	table.sort(files)
	
	for i,file in ipairs(files) do
		print("Added custom levelpack (" .. world .. ") lua file " .. file)
		dofile("Data/Worlds/" .. world .. "/Lua/" .. file)
	end
	
	modsinuse = true
end