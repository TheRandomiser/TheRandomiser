ALPHABABA SOUP
by Randomiser	(Randomiser#0769 on discord)
Initial release: Feb 05 2020
===
A collection of levels I've made over the last few months. Levels are intended to feature a wide range of difficulty. As always, I'd love to hear any feedback, or if you find anything that seems like an unintended solution.

Features 101 winnable levels and a custom ending!
100% totals are 101/9/1

===

INSTALLATION:
Simply drop the 'Alphababa Soup' folder into your 'Baba Is You/Data/Worlds' folder.

The 'alphababasoupcustom.lua' file is a script that enables a custom ending in the final level. Each world folder now contains its own lua folder, so you don't have to do anything special to install it. If you get a message telling you it isn't installed, you may be playing on a version that doesn't support custom lua.